export default function NotFoundPage() {
  return <h1>404 — Strona nie istnieje</h1>;
}