from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()  # Instancja SQLAlchemy bez przypisania do app
